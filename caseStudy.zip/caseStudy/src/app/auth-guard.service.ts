import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, of, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthGuardService {

  constructor(private router: Router) { }

  setToken(id: string): void {
    localStorage.setItem('employeeId',id);
  }

  getToken():string|null{
    return localStorage.getItem('employeeId');
  }

  isLoggedIn(){
    console.log(typeof(this.getToken()));
    return this.getToken()!==null;
  }

  logout(){
    localStorage.removeItem('token');
    this.router.navigate(['login']);
  }

  login({employeeId, password}: any): Observable<any>{
    if(employeeId==='1111' && password==='1234'){
      this.setToken(employeeId);
      return of({employeeId: 1111});
    }
    return throwError(new Error('Failed to login'));
  }
}
