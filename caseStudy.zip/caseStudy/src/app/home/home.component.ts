import { Component, OnInit } from '@angular/core';
import { AuthGuardService } from '../auth-guard.service';
import { EmployeesService,employeeType } from '../employees.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  employeeDetails:employeeType;
  constructor(private authSvc: AuthGuardService, private employeeSvc: EmployeesService) {
    this.employeeDetails = this.employeeSvc.getLoggedInEmployeeDetails();
  }

  ngOnInit(): void {
  }

  handleLogout(){
    this.authSvc.logout();
  }

  

}
