import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthGuardService } from '../auth-guard.service';
import { EmployeesService } from '../employees.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {

  constructor(private authSrv: AuthGuardService, private router: Router, private employeeSvc: EmployeesService) { }

  ngOnInit(): void {
  }

  loginForm = new FormGroup({
    employeeId: new FormControl('',Validators.required),
    firstName: new FormControl('',Validators.required),
    lastName: new FormControl('',Validators.required),
    password: new FormControl('',Validators.required),
  });

  get employeeId() { return this.loginForm.get('employeeId'); }
  get firstName() { return this.loginForm.get('firstName'); }
  get lastName() { return this.loginForm.get('lastName'); }
  get password() { return this.loginForm.get('password'); }

  onSubmit(){
    console.log(this.loginForm.value);
    if(this.loginForm.valid){
      this.authSrv.login(this.loginForm.value).subscribe(
        (result)=>{
          console.log("result:", result)
          // this.employeeSvc.loggedInEmployeeId = result.employeeId;
          this.router.navigate(['home']);
        },
        (err: Error)=>{
          alert(err.message);
        }
      );
    }
  }

}
